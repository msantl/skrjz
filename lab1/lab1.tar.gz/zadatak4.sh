#!/bin/bash

if [ $# -lt 2 ]
	then
	echo "Potrebno je navesti 2 argumenta"
	exit
	fi

ULAZ=$1
IZLAZ=$2

if [ ! -d $ULAZ ]
	then
	echo "Ne postoji kazalo $ULAZ"
	exit
	fi

mkdir -p $IZLAZ

for f in $(ls $ULAZ)
	do
		if [ -f $ULAZ/$f ]
			then
				kazalo=$( stat $ULAZ/$f -c "%Y" | date +"%Y-%m" )
				mkdir -p $IZLAZ/$kazalo
				mv $ULAZ/$f $IZLAZ/$kazalo
			fi
	done

